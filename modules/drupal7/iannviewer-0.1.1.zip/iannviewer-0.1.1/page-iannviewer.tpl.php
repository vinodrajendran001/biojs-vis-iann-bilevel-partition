<?php
print $content;
?>